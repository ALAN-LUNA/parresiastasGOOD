

<?php $__env->startSection('title', 'Empleados'); ?>

<?php $__env->startSection('content'); ?>

<div class="table-responsive table-scroll" data-mdb-perfect-scrollbar="true" style="position: relative; height: 700px">
    <table class="table table-responsive table-bordered"">
        <thead>
            <tr>
                <th scope="col">Id</th>
                <th scope="col">Nombre</th>
                <th scope="col">Nombre de usuario</th>
                <th scope="col">Correo</th>
                <th scope="col">Eliminar</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($usuario->ID); ?></td>
                    <td><?php echo e($usuario->display_name); ?></td>
                    <td><?php echo e($usuario->user_nicename); ?></td>
                    <td><?php echo e($usuario->user_email); ?></td>
                    <td>
                        <button class="btn btn-round btn-danger"><i class="fa fa-trash"></i></button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alanl\Desktop\laravelUI\resources\views/empleados.blade.php ENDPATH**/ ?>