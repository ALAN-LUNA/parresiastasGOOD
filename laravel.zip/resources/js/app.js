import './bootstrap';

// You can specify which plugins you need
import { Tooltip, Toast, Popover } from 'bootstrap';
import Alert from 'bootstrap/js/dist/alert';

